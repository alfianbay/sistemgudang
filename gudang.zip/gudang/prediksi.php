<?php
// Data historis permintaan barang (misalnya permintaan per bulan)
$data_historis = [120, 150, 100, 170, 200, 180, 160, 140, 190, 210, 230, 220];

// Fungsi untuk menghitung rata-rata bergerak (Moving Average)
function moving_average($data, $periode) {
    $result = [];
    for ($i = 0; $i <= count($data) - $periode; $i++) {
        $average = array_sum(array_slice($data, $i, $periode)) / $periode;
        $result[] = $average;
    }
    return $result;
}

// Prediksi permintaan berikutnya menggunakan rata-rata bergerak
function predict_next($data, $periode) {
    $average = array_sum(array_slice($data, -$periode)) / $periode;
    return $average;
}

// Tentukan periode untuk rata-rata bergerak
$periode = 3;

// Hitung Moving Average
$moving_averages = moving_average($data_historis, $periode);

// Prediksi permintaan bulan berikutnya
$prediksi_berikutnya = predict_next($data_historis, $periode);

// Tampilkan hasil
echo "<h3>Data Historis Permintaan Barang</h3>";
echo "<ul>";
foreach ($data_historis as $index => $value) {
    echo "<li>Bulan " . ($index + 1) . ": $value</li>";
}
echo "</ul>";

echo "<h3>Hasil Moving Average</h3>";
echo "<ul>";
foreach ($moving_averages as $index => $value) {
    echo "<li>Periode " . ($index + 1) . ": " . round($value, 2) . "</li>";
}
echo "</ul>";

echo "<h3>Prediksi Permintaan Bulan Berikutnya</h3>";
echo "<p>Prediksi: " . round($prediksi_berikutnya, 2) . "</p>";
?>
